// placeholder lib
pub fn hello() -> &'static str { "hello from lib" }
